package com.projeto04.Av1.entities;

public enum StatusPedido {
    PREPARACAO,
    POSTAGEM,
    COLETA,
    TRIAGEM,
    TRANSPORTE,
    ENTREGA,
    DEVOLUCAO,
    CONCLUIDA,
}
