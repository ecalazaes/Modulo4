package com.projeto04.Av1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Av1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
