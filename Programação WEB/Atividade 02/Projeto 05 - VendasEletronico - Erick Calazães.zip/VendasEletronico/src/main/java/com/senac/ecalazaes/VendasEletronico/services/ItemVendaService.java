package com.senac.ecalazaes.VendasEletronico.services;

import org.springframework.stereotype.Service;

@Service
public class ItemVendaService {
}
