package com.senac.ecalazaes.VendasEletronico.controllers;

public class ItemVendaController {
}
