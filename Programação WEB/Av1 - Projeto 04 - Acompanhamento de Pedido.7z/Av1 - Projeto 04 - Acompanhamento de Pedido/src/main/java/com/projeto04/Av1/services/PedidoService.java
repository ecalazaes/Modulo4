package com.projeto04.Av1.services;

import com.projeto04.Av1.entities.Pedido;
import com.projeto04.Av1.entities.StatusPedido;
import com.projeto04.Av1.repositories.PedidoRepository;
import com.projeto04.Av1.services.exceptions.PedidoNotFoundException;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class PedidoService {

    private PedidoRepository pedidoRepository;

    public PedidoService(PedidoRepository pedidoRepository) {
        this.pedidoRepository = pedidoRepository;
    }

    public Pedido obterPedidoPorId(Long id) {
        Optional<Pedido> pedidoOptional = pedidoRepository.findById(id);
        return pedidoOptional.orElseThrow(() -> new PedidoNotFoundException("Pedido não encontrado!"));
    }

    public Pedido atualizarStatus(Long id, StatusPedido novoStatus) {
        Pedido pedido = obterPedidoPorId(id);
        pedido.setStatus(novoStatus);
        pedido.setDataAtualizacao(LocalDateTime.now());
        return pedidoRepository.save(pedido);
    }
}
