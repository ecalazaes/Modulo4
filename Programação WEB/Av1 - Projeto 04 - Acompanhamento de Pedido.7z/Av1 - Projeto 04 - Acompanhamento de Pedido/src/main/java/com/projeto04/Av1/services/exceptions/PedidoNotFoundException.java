package com.projeto04.Av1.services.exceptions;

import java.io.Serial;

public class PedidoNotFoundException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = 1L;

    public PedidoNotFoundException(String msg) {
        super(msg);
    }
}
