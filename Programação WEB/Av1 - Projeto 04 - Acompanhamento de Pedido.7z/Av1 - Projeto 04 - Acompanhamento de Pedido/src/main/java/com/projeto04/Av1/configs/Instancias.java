package com.projeto04.Av1.configs;

import com.projeto04.Av1.entities.Pedido;
import com.projeto04.Av1.entities.StatusPedido;
import com.projeto04.Av1.repositories.PedidoRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDateTime;
import java.util.Arrays;

@Configuration
public class Instancias implements CommandLineRunner {

    private PedidoRepository pedidoRepository;

    public Instancias(PedidoRepository pedidoRepository) {
        this.pedidoRepository = pedidoRepository;
    }

    @Override
    public void run(String... args) throws Exception {

        pedidoRepository.deleteAll();

        Pedido pedido1 = new Pedido(null, StatusPedido.PROCESSANDO, LocalDateTime.now());
        Pedido pedido2 = new Pedido(null, StatusPedido.AUTORIZADO, LocalDateTime.now());
        Pedido pedido3 = new Pedido(null, StatusPedido.CANCELADO, LocalDateTime.now());
        Pedido pedido4 = new Pedido(null, StatusPedido.ENVIADO, LocalDateTime.now());
        Pedido pedido5 = new Pedido(null, StatusPedido.ENTREGUE, LocalDateTime.now());

        pedidoRepository.saveAll(Arrays.asList(pedido1, pedido2, pedido3, pedido4, pedido5));

    }
}
