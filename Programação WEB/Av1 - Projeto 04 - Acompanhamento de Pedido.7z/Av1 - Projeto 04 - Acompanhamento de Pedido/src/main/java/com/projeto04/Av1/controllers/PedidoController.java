package com.projeto04.Av1.controllers;

import com.projeto04.Av1.entities.Pedido;
import com.projeto04.Av1.entities.StatusPedido;
import com.projeto04.Av1.services.PedidoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("pedido")
public class PedidoController {

    private PedidoService pedidoService;

    public PedidoController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<Pedido> obterPedidoPorId(@PathVariable Long id) {
        Pedido pedido = pedidoService.obterPedidoPorId(id);
        return ResponseEntity.ok(pedido);
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<Pedido> atualizarStatus(@PathVariable Long id, @RequestParam StatusPedido novoStatus) {
        Pedido pedido = pedidoService.atualizarStatus(id, novoStatus);
        return ResponseEntity.ok(pedido);
    }
}
