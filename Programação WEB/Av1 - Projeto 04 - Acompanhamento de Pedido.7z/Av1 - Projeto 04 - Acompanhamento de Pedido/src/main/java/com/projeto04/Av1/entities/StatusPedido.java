package com.projeto04.Av1.entities;

public enum StatusPedido {
    PROCESSANDO,
    CANCELADO,
    AUTORIZADO,
    ENVIADO,
    ENTREGUE,
}
