package com.github.com.TesteDockerFile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteDockerFileApplicationTests {

	@Test
	void contextLoads() {
	}

}
