package com.github.com.TesteDockerFile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesteDockerFileApplication {

	public static void main(String[] args) {
		SpringApplication.run(TesteDockerFileApplication.class, args);
	}

}
